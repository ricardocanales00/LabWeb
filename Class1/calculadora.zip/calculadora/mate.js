exports.producto = function(a,b){
	return a * b;
};

exports.suma = function(a,b){
	return a + b
};

exports.resta = function(a,b){
	return a - b
};

exports.division = function(a,b){
	return a / b
};

exports.modulo = function(a,b){
	return a % b
};